<?php

namespace clinic\assets;

use yii\web\AssetBundle;

class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/layout.css',
        'css/style.css',
        'css/dental.css',
    ];
    public $js = [
        'js/script.js',
    ];
    public $depends = [
        'common\assets\BootstrapAsset',
    ];
}
